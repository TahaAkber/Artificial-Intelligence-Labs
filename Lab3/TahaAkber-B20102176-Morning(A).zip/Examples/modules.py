# ALL MODULES

def greeting(name):
    print("Hello, " + name)


person1 = {
    "name": "Taha",
    "age": "21",
    "country": "Pakistan",
    "contact NO": +92-3462999417,
}
