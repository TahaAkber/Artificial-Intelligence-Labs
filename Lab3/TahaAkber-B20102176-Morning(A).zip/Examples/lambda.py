#Example 1
#lambda
x = lambda a:a+10
print(x(5))

#Example 1

x = lambda a:a+10
print(x(5))

#Example 2
x = lambda a,b,c:a+b+c

print(x(3, 4, 5))

#Example 3
x = lambda a,b:a*b
print(x(5,4))

