# Example 1
import modules
modules.greeting("TAHA AKBER")

# Example 2
a = modules.person1["name"]
b = modules.person1["country"]
print(a)
print(b)
