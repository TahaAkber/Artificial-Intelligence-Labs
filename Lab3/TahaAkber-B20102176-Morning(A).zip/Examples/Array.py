# Example practice of Array
cars = ["Accord", "corolla", "suzuki", "honda"]

# Check Element at 0th index
print(cars[0])

# Modify 0th Index
cars[0] = "BMW"

# length of array is same as list
print(len(cars))

# Using loop to print Array
for x in cars:
    print(x)
